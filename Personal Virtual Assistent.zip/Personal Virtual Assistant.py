#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#pip install pyttsx3
#pip install SpeechRecognition
#pip install pyaudio
#pip install wikipedia
#pip install webbrowser
#pip install pywhatkit
#pip install pyjokes


# In[1]:


import pyttsx3
import speech_recognition as sr
import datetime
import wikipedia
import webbrowser
import pywhatkit
import os
import smtplib
import pyjokes


# In[2]:


for index, name in enumerate(sr.Microphone.list_microphone_names()):
    print("Microphone with name \"{1}\" found for `Microphone(device_index={0})`".format(index, name))


# In[ ]:


engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
# print(voices[0].id)
engine.setProperty('voice', voices[1].id)


def speak(audio):
    engine.say(audio)
    engine.runAndWait()


def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour >= 0 and hour < 12:
        speak("Good Morning Sir!")

    elif hour >= 12 and hour < 18:
        speak("Good Afternoon Sir!")

    else:
        speak("Good Evening Sir!")

    speak("Hello this is baby. You are welcome to the Python charmers' world . Please tell me how may I help you")


def takeCommand():
    # It takes microphone input from the user and returns string output

    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source)

    try:
        print("Recognizing...")
        query = r.recognize_google(audio, language='en-in')
        print(f"User said: {query}\n")

    except Exception as e:
        # print(e)
        print("Say that again please...")
        return "None"
    return query

def sendEmail(to,content):
    server = smtplib.SMTP('smtp.gmail.com',587)
    server.ehlo()
    server.starttls()
    server.login(' sharmaparth2250@mail.com ','7874726933')
    server.sendmail('parthsharma7016@gmail.com',to ,content)
    server.close()


if __name__ == '__main__':
    wishMe()
    while True:
        query = takeCommand().lower()

        if 'wikipedia' in query:
            speak("searching wikipedia...")
            query = query.replace("wikipedia","")
            results = wikipedia.summary(query,sentences=3)
            speak("According to wikipedia... ")
            print(results)
            speak(results)

        elif 'open youtube' in query:
            webbrowser.open("youtube.com")


        elif 'in youtube search' in query:
            speak("searching in youtube...")
            query = query.replace("in youtube search", "")
            web= 'https://www.youtube.com/results?search_query='+query
            webbrowser.open(web)
            speak("done sir!!")

        elif 'open google' in query:
            webbrowser.open("google.com")


        elif 'in google search' in query:
            speak("searching in google...")
            query = query.replace("in google search", "")
            pywhatkit.search(query)
            speak("done sir!!")

        elif 'play music' in query:
            music=takeCommand()
            speak("searching for music...")
            pywhatkit.playonyt(music)
            speak("done sir!!")

        elif 'news' in query:
            speak("searching for today's news...")
            webbrowser.open("https://timesofindia.indiatimes.com/india")


        elif 'open stackoverflow' in query:
            speak("searching in stackoverfolw...")
            webbrowser.open("stackoverflow.com")

        elif 'tell me jokes' in query:
           get = pyjokes.get_joke()
           speak(get)

        elif 'play series' in query:
            series_dir = 'F:\\python\\Deep Learning A-Z™ Hands-On Artificial Neural Networks'
            series = os.listdir(movie_dir)
            print(series_dir)
            os.startfile(os.path.join(series_dir,series[0]))


        elif 'the time' in query:
            strTime = datetime.datetime.now().strftime("%H:%M:%S")
            speak(f" Sir, the time is {strTime}")

        elif 'send email' in query:
            try:
                speak("What Should I Say Sir?")
                content = takeCommand()
                to = "parthsharma7016@gmail.com"
                sendEmail(to,content)
                speak("Email has been sent")

            except Exception as e:
                print(e)
                speak(" sorry sir! i cannot sent mail")

        elif 'exit' in query:
            speak("Have a nice day")
            break


# In[ ]:




